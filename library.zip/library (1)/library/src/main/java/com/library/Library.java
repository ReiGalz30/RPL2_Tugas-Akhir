package com.library;

import com.library.view.MainView;
import javax.swing.SwingUtilities;

public class Library {
    public static void main(String[] args) {
        // Menjalankan GUI di Thread yang aman
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new MainView().setVisible(true);
            }
        });
    }
}