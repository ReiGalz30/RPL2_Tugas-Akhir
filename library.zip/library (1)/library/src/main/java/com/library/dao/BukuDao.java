package com.library.dao;

import com.library.entity.Buku;
import java.util.List;

public interface BukuDao {
    public void saveBuku(Buku buku);
    public List<Buku> getBukuList();
    public void deleteBuku(int id);
    public Buku getBukuById(int id);
}