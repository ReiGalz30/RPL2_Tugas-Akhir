package com.library.service;

import com.library.dao.BukuDao;
import com.library.entity.Buku;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class BukuService {

    @Autowired
    private BukuDao bukuDao;

    @Transactional // Spring akan otomatis handle Begin & Commit transaksi DB
    public void saveBuku(Buku buku) {
        bukuDao.saveBuku(buku);
    }

    @Transactional
    public List<Buku> getBukuList() {
        return bukuDao.getBukuList();
    }

    @Transactional
    public Buku getBuku(int id) {
        return bukuDao.getBukuById(id);
    }

    @Transactional
    public void deleteBuku(int id) {
        bukuDao.deleteBuku(id);
    }
}