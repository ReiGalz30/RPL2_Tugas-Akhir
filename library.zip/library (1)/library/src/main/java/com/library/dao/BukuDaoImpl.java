package com.library.dao;

import com.library.entity.Buku;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository // Menandakan ini adalah komponen DAO untuk Spring
public class BukuDaoImpl implements BukuDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public void saveBuku(Buku buku) {
        Session session = sessionFactory.getCurrentSession();
        session.saveOrUpdate(buku); // Otomatis Insert jika baru, Update jika ada ID
    }

    @Override
    public List<Buku> getBukuList() {
        Session session = sessionFactory.getCurrentSession();
        Query<Buku> query = session.createQuery("from Buku", Buku.class);
        return query.getResultList();
    }

    @Override
    public Buku getBukuById(int id) {
        Session session = sessionFactory.getCurrentSession();
        return session.get(Buku.class, id);
    }

    @Override
    public void deleteBuku(int id) {
        Session session = sessionFactory.getCurrentSession();
        Query query = session.createQuery("delete from Buku where id=:bookId");
        query.setParameter("bookId", id);
        query.executeUpdate();
    }
}